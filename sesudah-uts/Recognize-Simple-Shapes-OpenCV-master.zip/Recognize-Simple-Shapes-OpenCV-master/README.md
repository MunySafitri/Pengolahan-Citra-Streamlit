# TDT4265 - Computer Vision

Project to recognize simple figures with openCV
